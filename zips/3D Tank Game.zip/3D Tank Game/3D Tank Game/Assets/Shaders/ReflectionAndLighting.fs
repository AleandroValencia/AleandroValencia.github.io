#version 430 core

out vec4 color;

in vec3 Position;
in vec3 Normal;

uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 lightColor;
uniform vec3 cameraPos;
uniform samplerCube skybox;

void main()
{
	// Ambient
	float ambientStrength = 0.1f;
	vec3 ambient = ambientStrength * lightColor;	
	
	// Diffuse
	vec3 norm = normalize(Normal);
	vec3 lightDir = normalize(lightPos - Position);	
	float diff = max(dot(norm, lightDir), 0.0f);
	vec3 diffuse = diff * lightColor;	// times light color
		
	// Specular
	float specularStrength = 0.5f;
	vec3 viewDir = normalize(viewPos - Position);
	vec3 reflectDir = reflect(-lightDir, norm);
	float spec = pow(max(dot(viewDir, reflectDir), 0.0f), 32);
	vec3 specular = specularStrength * spec * lightColor;
	
	vec3 result = (ambient + diffuse + specular);
	vec4 resultant = vec4(result, 1.0f);

	vec3 I = normalize(Position - cameraPos);
	vec3 R = reflect(I, normalize(Normal));
	color = texture(skybox, R) * resultant;
}