3D Tank Game - Aleandro Valencia
----------------------------

Made to be similar to Robotron game for University project.

WARNING! Music might be loud.

MENUS
-----
- Use 'w' and 'd' to navigate menus.
- Press space to select an option.
- Multiplayer is currently disabled. You won't be able to select it.


CONTROLS
--------
- NOTE: Please turn off caps lock
- 'w' : moves the player forward.
- 'a' : rotate player anticlockwise
- 'd' : rotate player clockwise
- ' '(space): shoot a bullet forward in front of player
- NOTE: You can't shoot and move/rotate at the same time.


POWER UPS
---------
- NOTE: The collision with the shapes work. You just have to get really close.
	It's hard to tell because they're floating on the plane and they don't 
	have a shadow.
- Cube powerup increases speed.
- All powerups increase score by 10.
- Every 100 points gains you another life.


ENEMY
-----
- The enemies wander.
- Once all enemies are defeated, you progress a level.
- NOTE: Loading the next level might take a second. But if you start a new game(in game 
	from game over screen), the load times will be faster if you've already reached 
	that level.
- Every level another enemy is added.
- If you collide with an enemy, the level is restarted, all dead enemies are respawned
and the player spawns in the middle.


GRAPHIC NOTES
-------------
- The powerups (primitive shapes) reflect the skybox.
- There is a light source hovering over the plane. It oscillates in a circle around it.
This is visible on the objects (most noticeable on the castle).


MUSIC
-----
Russian national anthem instrumental


Known Issues
------------
- If you die consecutively really fast, you might get a lot of lives(around 40000000ish).
- Bullet sometimes goes through enemies without killing them. (only sometimes).
- Bullet does not disappear after colliding with enemies. They are superbullets.
- Bullet survives after loading next level.